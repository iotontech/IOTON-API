# Testing when two features collide

expected_results = {
    "K64F": {
        "desc": "test feature collisions",
        "exception_msg": "Configuration conflict. The feature IPV4 both added and removed." 
    }
}
